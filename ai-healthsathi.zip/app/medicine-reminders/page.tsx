"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Plus, Trash2, CheckCircle2, AlertCircle, Edit2, Pill } from "lucide-react"

interface Medicine {
  id: string
  name: string
  dosage: string
  frequency: string
  times: string[]
  reason: string
  startDate: string
  endDate?: string
  taken: boolean
  lastTaken?: string
}

export default function MedicineReminders() {
  const [medicines, setMedicines] = useState<Medicine[]>([
    {
      id: "1",
      name: "Aspirin",
      dosage: "500mg",
      frequency: "Twice daily",
      times: ["08:00", "20:00"],
      reason: "Pain relief",
      startDate: "2025-01-15",
      taken: true,
      lastTaken: "Today at 08:00",
    },
    {
      id: "2",
      name: "Vitamin D",
      dosage: "1000 IU",
      frequency: "Once daily",
      times: ["09:00"],
      reason: "Bone health",
      startDate: "2025-01-01",
      taken: false,
    },
  ])

  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    dosage: "",
    frequency: "Once daily",
    times: ["09:00"],
    reason: "",
    startDate: new Date().toISOString().split("T")[0],
    endDate: "",
  })

  const handleAddMedicine = () => {
    if (!formData.name || !formData.dosage) return

    if (editingId) {
      setMedicines(
        medicines.map((m) =>
          m.id === editingId
            ? {
                ...m,
                name: formData.name,
                dosage: formData.dosage,
                frequency: formData.frequency,
                times: formData.times,
                reason: formData.reason,
                startDate: formData.startDate,
                endDate: formData.endDate,
              }
            : m,
        ),
      )
      setEditingId(null)
    } else {
      const newMedicine: Medicine = {
        id: Date.now().toString(),
        name: formData.name,
        dosage: formData.dosage,
        frequency: formData.frequency,
        times: formData.times,
        reason: formData.reason,
        startDate: formData.startDate,
        endDate: formData.endDate || undefined,
        taken: false,
      }
      setMedicines([...medicines, newMedicine])
    }

    setFormData({
      name: "",
      dosage: "",
      frequency: "Once daily",
      times: ["09:00"],
      reason: "",
      startDate: new Date().toISOString().split("T")[0],
      endDate: "",
    })
    setShowForm(false)
  }

  const handleDeleteMedicine = (id: string) => {
    setMedicines(medicines.filter((m) => m.id !== id))
  }

  const handleMarkTaken = (id: string) => {
    setMedicines(
      medicines.map((m) =>
        m.id === id
          ? {
              ...m,
              taken: !m.taken,
              lastTaken: !m.taken
                ? `Today at ${new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}`
                : undefined,
            }
          : m,
      ),
    )
  }

  const handleEditMedicine = (medicine: Medicine) => {
    setFormData({
      name: medicine.name,
      dosage: medicine.dosage,
      frequency: medicine.frequency,
      times: medicine.times,
      reason: medicine.reason,
      startDate: medicine.startDate,
      endDate: medicine.endDate || "",
    })
    setEditingId(medicine.id)
    setShowForm(true)
  }

  const addTimeSlot = () => {
    setFormData({
      ...formData,
      times: [...formData.times, "12:00"],
    })
  }

  const removeTimeSlot = (index: number) => {
    setFormData({
      ...formData,
      times: formData.times.filter((_, i) => i !== index),
    })
  }

  const updateTimeSlot = (index: number, value: string) => {
    const newTimes = [...formData.times]
    newTimes[index] = value
    setFormData({
      ...formData,
      times: newTimes,
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/" className="flex items-center gap-2 text-emerald-600 hover:text-emerald-700 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
          <h1 className="text-3xl font-bold text-slate-900">Medicine Reminders</h1>
          <p className="text-slate-600 mt-2">Never miss a dose with smart reminders</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Add Medicine Button */}
        <div className="mb-8">
          <Button
            onClick={() => {
              setShowForm(!showForm)
              setEditingId(null)
              setFormData({
                name: "",
                dosage: "",
                frequency: "Once daily",
                times: ["09:00"],
                reason: "",
                startDate: new Date().toISOString().split("T")[0],
                endDate: "",
              })
            }}
            className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white"
            size="lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Add New Medicine
          </Button>
        </div>

        {/* Add/Edit Medicine Form */}
        {showForm && (
          <Card className="p-8 mb-8 border-slate-200">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">
              {editingId ? "Edit Medicine" : "Add New Medicine"}
            </h2>
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Medicine Name</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="E.g., Aspirin"
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Dosage</label>
                  <input
                    type="text"
                    value={formData.dosage}
                    onChange={(e) => setFormData({ ...formData, dosage: e.target.value })}
                    placeholder="E.g., 500mg"
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Frequency</label>
                  <select
                    value={formData.frequency}
                    onChange={(e) => setFormData({ ...formData, frequency: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option>Once daily</option>
                    <option>Twice daily</option>
                    <option>Three times daily</option>
                    <option>Every 4 hours</option>
                    <option>Every 6 hours</option>
                    <option>Every 8 hours</option>
                    <option>As needed</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Reason for Medicine</label>
                  <input
                    type="text"
                    value={formData.reason}
                    onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                    placeholder="E.g., Pain relief"
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-3">Reminder Times</label>
                <div className="space-y-2">
                  {formData.times.map((time, idx) => (
                    <div key={idx} className="flex gap-2">
                      <input
                        type="time"
                        value={time}
                        onChange={(e) => updateTimeSlot(idx, e.target.value)}
                        className="flex-1 px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                      {formData.times.length > 1 && (
                        <button
                          onClick={() => removeTimeSlot(idx)}
                          className="px-3 py-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                <button
                  onClick={addTimeSlot}
                  className="mt-2 text-sm text-emerald-600 hover:text-emerald-700 font-medium"
                >
                  + Add another time
                </button>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Start Date</label>
                  <input
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">End Date (Optional)</label>
                  <input
                    type="date"
                    value={formData.endDate}
                    onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={handleAddMedicine}
                  className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white"
                >
                  {editingId ? "Update Medicine" : "Add Medicine"}
                </Button>
                <Button
                  onClick={() => {
                    setShowForm(false)
                    setEditingId(null)
                  }}
                  variant="outline"
                  className="flex-1 border-slate-300"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Medicines List */}
        <div className="space-y-4">
          {medicines.length === 0 ? (
            <Card className="p-12 text-center border-slate-200">
              <Pill className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-600 text-lg">No medicines added yet</p>
              <p className="text-slate-500 text-sm mt-1">Add your first medicine to get started with reminders</p>
            </Card>
          ) : (
            medicines.map((medicine) => (
              <Card
                key={medicine.id}
                className={`p-6 border-2 transition ${medicine.taken ? "border-emerald-200 bg-emerald-50" : "border-slate-200"}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-xl font-bold text-slate-900">{medicine.name}</h3>
                      {medicine.taken && <CheckCircle2 className="w-5 h-5 text-emerald-600" />}
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-slate-500 uppercase tracking-wide">Dosage</p>
                        <p className="text-sm font-medium text-slate-900">{medicine.dosage}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 uppercase tracking-wide">Frequency</p>
                        <p className="text-sm font-medium text-slate-900">{medicine.frequency}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 uppercase tracking-wide">Reason</p>
                        <p className="text-sm font-medium text-slate-900">{medicine.reason}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 uppercase tracking-wide">Times</p>
                        <p className="text-sm font-medium text-slate-900">{medicine.times.join(", ")}</p>
                      </div>
                    </div>
                    {medicine.lastTaken && (
                      <p className="text-sm text-emerald-600 flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" />
                        Taken {medicine.lastTaken}
                      </p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleMarkTaken(medicine.id)}
                      className={`px-4 py-2 rounded-lg font-medium transition ${
                        medicine.taken
                          ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-200"
                          : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                      }`}
                    >
                      {medicine.taken ? "Taken" : "Mark Taken"}
                    </button>
                    <button
                      onClick={() => handleEditMedicine(medicine)}
                      className="px-3 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteMedicine(medicine.id)}
                      className="px-3 py-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>

        {/* Tips Section */}
        <Card className="mt-12 p-6 border-blue-200 bg-blue-50">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-blue-900">Tips for Better Medicine Management</p>
              <ul className="text-sm text-blue-800 mt-2 space-y-1">
                <li>• Set reminders at consistent times each day</li>
                <li>• Keep medicines in a visible place as a visual reminder</li>
                <li>• Use a pill organizer to organize medicines by day and time</li>
                <li>• Mark doses as taken immediately after taking them</li>
                <li>• Consult your doctor before stopping any medicine</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
