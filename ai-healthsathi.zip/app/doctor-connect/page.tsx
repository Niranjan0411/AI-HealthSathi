"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, MessageCircle, Video, Phone, Star, MapPin, Clock, CheckCircle2, Send } from "lucide-react"

interface Doctor {
  id: string
  name: string
  specialty: string
  experience: string
  rating: number
  reviews: number
  location: string
  availability: string
  consultationFee: number
  image: string
  languages: string[]
  qualifications: string[]
}

interface Message {
  id: string
  sender: "user" | "doctor"
  text: string
  timestamp: string
}

export default function DoctorConnect() {
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null)
  const [consultationType, setConsultationType] = useState<"chat" | "video" | "phone" | null>(null)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      sender: "doctor",
      text: "Hello! I'm Dr. Sharma. How can I help you today?",
      timestamp: "10:30 AM",
    },
  ])
  const [newMessage, setNewMessage] = useState("")

  const doctors: Doctor[] = [
    {
      id: "1",
      name: "Dr. Rajesh Sharma",
      specialty: "General Practitioner",
      experience: "15 years",
      rating: 4.8,
      reviews: 342,
      location: "City Medical Center",
      availability: "Available now",
      consultationFee: 300,
      image: "/doctor-male.jpg",
      languages: ["Hindi", "English", "Marathi"],
      qualifications: ["MBBS", "MD"],
    },
    {
      id: "2",
      name: "Dr. Priya Patel",
      specialty: "Cardiologist",
      experience: "12 years",
      rating: 4.9,
      reviews: 287,
      location: "Heart Care Hospital",
      availability: "Available in 30 mins",
      consultationFee: 500,
      image: "/doctor-female.jpg",
      languages: ["Hindi", "English", "Gujarati"],
      qualifications: ["MBBS", "MD", "DM Cardiology"],
    },
    {
      id: "3",
      name: "Dr. Amit Singh",
      specialty: "Pediatrician",
      experience: "10 years",
      rating: 4.7,
      reviews: 215,
      location: "Child Health Clinic",
      availability: "Available tomorrow",
      consultationFee: 250,
      image: "/doctor-male-2.jpg",
      languages: ["Hindi", "English", "Punjabi"],
      qualifications: ["MBBS", "MD Pediatrics"],
    },
    {
      id: "4",
      name: "Dr. Neha Gupta",
      specialty: "Dermatologist",
      experience: "8 years",
      rating: 4.6,
      reviews: 198,
      location: "Skin Care Center",
      availability: "Available now",
      consultationFee: 350,
      image: "/doctor-female-2.jpg",
      languages: ["Hindi", "English"],
      qualifications: ["MBBS", "MD Dermatology"],
    },
  ]

  const handleSendMessage = () => {
    if (!newMessage.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      sender: "user",
      text: newMessage,
      timestamp: new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
    }

    setMessages([...messages, userMessage])
    setNewMessage("")

    // Simulate doctor response
    setTimeout(() => {
      const doctorMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: "doctor",
        text: "Thank you for sharing that information. Let me analyze your symptoms and provide recommendations.",
        timestamp: new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
      }
      setMessages((prev) => [...prev, doctorMessage])
    }, 1000)
  }

  if (selectedDoctor && consultationType) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
        {/* Header */}
        <div className="bg-white border-b border-slate-200">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <button
              onClick={() => {
                setSelectedDoctor(null)
                setConsultationType(null)
                setMessages([
                  {
                    id: "1",
                    sender: "doctor",
                    text: "Hello! How can I help you today?",
                    timestamp: "10:30 AM",
                  },
                ])
              }}
              className="flex items-center gap-2 text-emerald-600 hover:text-emerald-700 mb-4"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </button>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-slate-900">{selectedDoctor.name}</h1>
                <p className="text-slate-600">{selectedDoctor.specialty}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-slate-600">
                  {consultationType === "chat" && "Chat Consultation"}
                  {consultationType === "video" && "Video Consultation"}
                  {consultationType === "phone" && "Phone Consultation"}
                </p>
                <p className="text-lg font-semibold text-slate-900">₹{selectedDoctor.consultationFee}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Chat Area */}
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="bg-white rounded-lg border border-slate-200 flex flex-col h-[600px]">
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                      message.sender === "user"
                        ? "bg-emerald-500 text-white rounded-br-none"
                        : "bg-slate-100 text-slate-900 rounded-bl-none"
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                    <p className={`text-xs mt-1 ${message.sender === "user" ? "text-emerald-100" : "text-slate-500"}`}>
                      {message.timestamp}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Input Area */}
            <div className="border-t border-slate-200 p-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                  placeholder="Type your message..."
                  className="flex-1 px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <Button onClick={handleSendMessage} className="bg-emerald-500 hover:bg-emerald-600 text-white">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Consultation Info */}
          <Card className="mt-6 p-6 border-blue-200 bg-blue-50">
            <div className="flex gap-3">
              <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-blue-900">Consultation Guidelines</p>
                <ul className="text-sm text-blue-800 mt-2 space-y-1">
                  <li>• Be clear and specific about your symptoms</li>
                  <li>• Provide relevant medical history</li>
                  <li>• Follow the doctor's advice and recommendations</li>
                  <li>• Ask for clarification if needed</li>
                  <li>• This consultation is for guidance only, not a substitute for in-person examination</li>
                </ul>
              </div>
            </div>
          </Card>
        </div>
      </div>
    )
  }

  if (selectedDoctor) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
        {/* Header */}
        <div className="bg-white border-b border-slate-200">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <button
              onClick={() => setSelectedDoctor(null)}
              className="flex items-center gap-2 text-emerald-600 hover:text-emerald-700 mb-4"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Doctors
            </button>
          </div>
        </div>

        {/* Doctor Profile */}
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid md:grid-cols-3 gap-8">
            {/* Doctor Info */}
            <div className="md:col-span-2">
              <Card className="p-8 border-slate-200 mb-6">
                <div className="flex gap-6 mb-6">
                  <img
                    src={selectedDoctor.image || "/placeholder.svg"}
                    alt={selectedDoctor.name}
                    className="w-32 h-32 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <h1 className="text-3xl font-bold text-slate-900">{selectedDoctor.name}</h1>
                    <p className="text-lg text-emerald-600 font-medium">{selectedDoctor.specialty}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${i < Math.floor(selectedDoctor.rating) ? "fill-amber-400 text-amber-400" : "text-slate-300"}`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-slate-600">
                        {selectedDoctor.rating} ({selectedDoctor.reviews} reviews)
                      </span>
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4 mb-6">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Experience</p>
                    <p className="font-semibold text-slate-900">{selectedDoctor.experience}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Location</p>
                    <p className="font-semibold text-slate-900 flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {selectedDoctor.location}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Availability</p>
                    <p className="font-semibold text-slate-900 flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {selectedDoctor.availability}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Consultation Fee</p>
                    <p className="font-semibold text-slate-900">₹{selectedDoctor.consultationFee}</p>
                  </div>
                </div>

                <div className="mb-6">
                  <p className="text-sm text-slate-600 mb-2">Qualifications</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedDoctor.qualifications.map((qual, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full text-sm font-medium"
                      >
                        {qual}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <p className="text-sm text-slate-600 mb-2">Languages</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedDoctor.languages.map((lang, idx) => (
                      <span key={idx} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                        {lang}
                      </span>
                    ))}
                  </div>
                </div>
              </Card>
            </div>

            {/* Consultation Options */}
            <div>
              <Card className="p-6 border-slate-200 sticky top-6">
                <h3 className="text-lg font-bold text-slate-900 mb-4">Choose Consultation Type</h3>
                <div className="space-y-3">
                  <button
                    onClick={() => setConsultationType("chat")}
                    className="w-full p-4 border-2 border-slate-200 rounded-lg hover:border-emerald-500 hover:bg-emerald-50 transition text-left"
                  >
                    <div className="flex items-center gap-3">
                      <MessageCircle className="w-6 h-6 text-emerald-600" />
                      <div>
                        <p className="font-semibold text-slate-900">Chat</p>
                        <p className="text-sm text-slate-600">Text-based consultation</p>
                      </div>
                    </div>
                  </button>
                  <button
                    onClick={() => setConsultationType("video")}
                    className="w-full p-4 border-2 border-slate-200 rounded-lg hover:border-emerald-500 hover:bg-emerald-50 transition text-left"
                  >
                    <div className="flex items-center gap-3">
                      <Video className="w-6 h-6 text-emerald-600" />
                      <div>
                        <p className="font-semibold text-slate-900">Video Call</p>
                        <p className="text-sm text-slate-600">Face-to-face consultation</p>
                      </div>
                    </div>
                  </button>
                  <button
                    onClick={() => setConsultationType("phone")}
                    className="w-full p-4 border-2 border-slate-200 rounded-lg hover:border-emerald-500 hover:bg-emerald-50 transition text-left"
                  >
                    <div className="flex items-center gap-3">
                      <Phone className="w-6 h-6 text-emerald-600" />
                      <div>
                        <p className="font-semibold text-slate-900">Phone Call</p>
                        <p className="text-sm text-slate-600">Voice consultation</p>
                      </div>
                    </div>
                  </button>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/" className="flex items-center gap-2 text-emerald-600 hover:text-emerald-700 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
          <h1 className="text-3xl font-bold text-slate-900">Doctor Connect</h1>
          <p className="text-slate-600 mt-2">Connect with qualified healthcare professionals</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Doctors Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {doctors.map((doctor) => (
            <Card
              key={doctor.id}
              className="border-slate-200 hover:shadow-lg transition cursor-pointer overflow-hidden"
              onClick={() => setSelectedDoctor(doctor)}
            >
              <img src={doctor.image || "/placeholder.svg"} alt={doctor.name} className="w-full h-40 object-cover" />
              <div className="p-4">
                <h3 className="font-bold text-slate-900 text-sm">{doctor.name}</h3>
                <p className="text-xs text-emerald-600 font-medium mb-2">{doctor.specialty}</p>
                <div className="flex items-center gap-1 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3 h-3 ${i < Math.floor(doctor.rating) ? "fill-amber-400 text-amber-400" : "text-slate-300"}`}
                    />
                  ))}
                  <span className="text-xs text-slate-600">({doctor.reviews})</span>
                </div>
                <div className="space-y-1 text-xs text-slate-600 mb-3">
                  <p>{doctor.experience}</p>
                  <p className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {doctor.availability}
                  </p>
                </div>
                <Button className="w-full bg-emerald-500 hover:bg-emerald-600 text-white text-xs">View Profile</Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
