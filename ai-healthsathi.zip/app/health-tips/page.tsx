"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Heart, Brain, Smile, Lightbulb, TrendingUp, BookOpen, Zap } from "lucide-react"

interface HealthTip {
  id: string
  category: string
  title: string
  description: string
  tips: string[]
  icon: React.ReactNode
  color: string
}

interface MoodEntry {
  id: string
  date: string
  mood: "excellent" | "good" | "neutral" | "sad" | "stressed"
  notes: string
  activities: string[]
}

export default function HealthTips() {
  const [selectedMood, setSelectedMood] = useState<"excellent" | "good" | "neutral" | "sad" | "stressed" | null>(null)
  const [moodNotes, setMoodNotes] = useState("")
  const [moodActivities, setMoodActivities] = useState<string[]>([])
  const [moodHistory, setMoodHistory] = useState<MoodEntry[]>([
    {
      id: "1",
      date: "2025-01-25",
      mood: "good",
      notes: "Had a good day at work",
      activities: ["Exercise", "Meditation"],
    },
    {
      id: "2",
      date: "2025-01-24",
      mood: "excellent",
      notes: "Spent time with family",
      activities: ["Family time", "Yoga"],
    },
    {
      id: "3",
      date: "2025-01-23",
      mood: "neutral",
      notes: "Regular day",
      activities: ["Work", "Reading"],
    },
  ])

  const moodOptions = [
    { value: "excellent", label: "Excellent", emoji: "😄", color: "from-green-400 to-emerald-500" },
    { value: "good", label: "Good", emoji: "🙂", color: "from-emerald-400 to-teal-500" },
    { value: "neutral", label: "Neutral", emoji: "😐", color: "from-yellow-400 to-amber-500" },
    { value: "sad", label: "Sad", emoji: "😢", color: "from-blue-400 to-cyan-500" },
    { value: "stressed", label: "Stressed", emoji: "😰", color: "from-red-400 to-orange-500" },
  ]

  const activityOptions = [
    "Exercise",
    "Meditation",
    "Yoga",
    "Reading",
    "Music",
    "Family time",
    "Friends",
    "Work",
    "Hobby",
    "Sleep",
    "Cooking",
    "Nature walk",
  ]

  const healthTips: HealthTip[] = [
    {
      id: "1",
      category: "Mental Health",
      title: "Stress Management",
      description: "Learn effective techniques to manage daily stress and anxiety",
      tips: [
        "Practice deep breathing exercises for 5-10 minutes daily",
        "Try progressive muscle relaxation before bed",
        "Maintain a consistent sleep schedule",
        "Limit caffeine and alcohol intake",
        "Engage in regular physical activity",
        "Practice mindfulness meditation",
      ],
      icon: <Brain className="w-8 h-8" />,
      color: "from-purple-500 to-pink-600",
    },
    {
      id: "2",
      category: "Physical Health",
      title: "Daily Exercise",
      description: "Incorporate movement into your daily routine for better health",
      tips: [
        "Aim for 30 minutes of moderate exercise daily",
        "Include both cardio and strength training",
        "Take short breaks to stretch every hour",
        "Walk or cycle for short distances",
        "Do yoga or tai chi for flexibility",
        "Stay active throughout the day",
      ],
      icon: <Zap className="w-8 h-8" />,
      color: "from-orange-500 to-red-600",
    },
    {
      id: "3",
      category: "Nutrition",
      title: "Healthy Eating",
      description: "Maintain a balanced diet for optimal health",
      tips: [
        "Eat plenty of fruits and vegetables",
        "Choose whole grains over refined carbs",
        "Include lean proteins in every meal",
        "Stay hydrated with 8-10 glasses of water daily",
        "Limit sugar and processed foods",
        "Eat smaller, frequent meals",
      ],
      icon: <Heart className="w-8 h-8" />,
      color: "from-red-500 to-pink-600",
    },
    {
      id: "4",
      category: "Sleep",
      title: "Quality Sleep",
      description: "Improve your sleep quality for better health and mood",
      tips: [
        "Maintain a consistent sleep schedule",
        "Create a dark, cool, quiet bedroom",
        "Avoid screens 1 hour before bed",
        "Limit caffeine after 2 PM",
        "Try relaxation techniques before sleep",
        "Aim for 7-9 hours of sleep nightly",
      ],
      icon: <Smile className="w-8 h-8" />,
      color: "from-indigo-500 to-blue-600",
    },
    {
      id: "5",
      category: "Emotional Wellness",
      title: "Emotional Balance",
      description: "Develop emotional resilience and maintain mental wellbeing",
      tips: [
        "Practice gratitude daily",
        "Maintain social connections",
        "Express your feelings openly",
        "Seek support when needed",
        "Practice self-compassion",
        "Engage in activities you enjoy",
      ],
      icon: <Lightbulb className="w-8 h-8" />,
      color: "from-yellow-500 to-amber-600",
    },
    {
      id: "6",
      category: "Preventive Care",
      title: "Regular Checkups",
      description: "Stay ahead of health issues with preventive care",
      tips: [
        "Schedule annual health checkups",
        "Monitor your vital signs regularly",
        "Get vaccinations as recommended",
        "Maintain dental hygiene",
        "Regular eye checkups",
        "Keep health records updated",
      ],
      icon: <TrendingUp className="w-8 h-8" />,
      color: "from-teal-500 to-green-600",
    },
  ]

  const handleAddMoodEntry = () => {
    if (!selectedMood) return

    const newEntry: MoodEntry = {
      id: Date.now().toString(),
      date: new Date().toISOString().split("T")[0],
      mood: selectedMood,
      notes: moodNotes,
      activities: moodActivities,
    }

    setMoodHistory([newEntry, ...moodHistory])
    setSelectedMood(null)
    setMoodNotes("")
    setMoodActivities([])
  }

  const toggleActivity = (activity: string) => {
    setMoodActivities((prev) => (prev.includes(activity) ? prev.filter((a) => a !== activity) : [...prev, activity]))
  }

  const getMoodColor = (mood: string) => {
    const moodOption = moodOptions.find((m) => m.value === mood)
    return moodOption?.color || "from-gray-400 to-gray-500"
  }

  const getMoodEmoji = (mood: string) => {
    const moodOption = moodOptions.find((m) => m.value === mood)
    return moodOption?.emoji || "😐"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/" className="flex items-center gap-2 text-emerald-600 hover:text-emerald-700 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
          <h1 className="text-3xl font-bold text-slate-900">Health Tips & Wellness</h1>
          <p className="text-slate-600 mt-2">Daily guidance for better health and emotional wellbeing</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Mood Tracker */}
        <Card className="p-8 mb-12 border-slate-200 bg-gradient-to-br from-slate-50 to-white">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">How Are You Feeling Today?</h2>

          {/* Mood Selection */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
            {moodOptions.map((mood) => (
              <button
                key={mood.value}
                onClick={() => setSelectedMood(mood.value as any)}
                className={`p-4 rounded-lg border-2 transition ${
                  selectedMood === mood.value
                    ? `border-slate-900 bg-gradient-to-br ${mood.color} text-white`
                    : "border-slate-200 hover:border-slate-300 bg-white"
                }`}
              >
                <div className="text-3xl mb-2">{mood.emoji}</div>
                <p className="text-sm font-medium">{mood.label}</p>
              </button>
            ))}
          </div>

          {/* Activities Selection */}
          {selectedMood && (
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-700 mb-3">What activities did you do today?</label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
                {activityOptions.map((activity) => (
                  <button
                    key={activity}
                    onClick={() => toggleActivity(activity)}
                    className={`px-3 py-2 rounded-lg text-sm font-medium transition ${
                      moodActivities.includes(activity)
                        ? "bg-emerald-500 text-white"
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    {activity}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Notes */}
          {selectedMood && (
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-700 mb-2">Add notes (optional)</label>
              <textarea
                value={moodNotes}
                onChange={(e) => setMoodNotes(e.target.value)}
                placeholder="How was your day? What's on your mind?"
                className="w-full h-24 p-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
              />
            </div>
          )}

          {/* Submit Button */}
          {selectedMood && (
            <Button
              onClick={handleAddMoodEntry}
              className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white"
              size="lg"
            >
              Save Mood Entry
            </Button>
          )}
        </Card>

        {/* Mood History */}
        {moodHistory.length > 0 && (
          <Card className="p-8 mb-12 border-slate-200">
            <h3 className="text-xl font-bold text-slate-900 mb-4">Your Mood History</h3>
            <div className="space-y-3">
              {moodHistory.slice(0, 5).map((entry) => (
                <div key={entry.id} className="flex items-start gap-4 p-4 bg-slate-50 rounded-lg">
                  <div className="text-3xl">{getMoodEmoji(entry.mood)}</div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <p className="font-semibold text-slate-900 capitalize">{entry.mood}</p>
                      <p className="text-sm text-slate-600">{new Date(entry.date).toLocaleDateString()}</p>
                    </div>
                    {entry.notes && <p className="text-sm text-slate-600 mb-2">{entry.notes}</p>}
                    {entry.activities.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {entry.activities.map((activity) => (
                          <span key={activity} className="text-xs bg-emerald-100 text-emerald-800 px-2 py-1 rounded">
                            {activity}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Health Tips Grid */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Daily Health Tips</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {healthTips.map((tip) => (
              <Card key={tip.id} className="p-6 border-slate-200 hover:shadow-lg transition">
                <div
                  className={`w-12 h-12 rounded-lg bg-gradient-to-br ${tip.color} flex items-center justify-center mb-4`}
                >
                  <div className="text-white">{tip.icon}</div>
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">{tip.title}</h3>
                <p className="text-sm text-slate-600 mb-4">{tip.description}</p>
                <ul className="space-y-2">
                  {tip.tips.slice(0, 3).map((t, idx) => (
                    <li key={idx} className="flex gap-2 text-sm text-slate-700">
                      <span className="text-emerald-600 font-bold">•</span>
                      <span>{t}</span>
                    </li>
                  ))}
                </ul>
                <Button variant="outline" className="w-full mt-4 border-slate-300 text-slate-900 bg-transparent">
                  Learn More
                </Button>
              </Card>
            ))}
          </div>
        </div>

        {/* Wellness Resources */}
        <Card className="p-8 border-blue-200 bg-blue-50">
          <div className="flex gap-4">
            <BookOpen className="w-6 h-6 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-blue-900">Wellness Resources</p>
              <ul className="text-sm text-blue-800 mt-2 space-y-1">
                <li>• Download our free wellness guide for comprehensive health tips</li>
                <li>• Join our community for daily motivation and support</li>
                <li>• Access guided meditation and yoga sessions</li>
                <li>• Get personalized health recommendations based on your mood</li>
                <li>• Connect with wellness experts for personalized advice</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
