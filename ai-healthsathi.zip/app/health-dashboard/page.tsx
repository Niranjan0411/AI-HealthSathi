"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Plus, Heart, Activity, Droplet, Weight } from "lucide-react"
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface HealthMetric {
  id: string
  date: string
  bloodPressure?: string
  heartRate?: number
  weight?: number
  bloodSugar?: number
  steps?: number
  waterIntake?: number
  temperature?: number
}

export default function HealthDashboard() {
  const [metrics, setMetrics] = useState<HealthMetric[]>([
    {
      id: "1",
      date: "2025-01-25",
      bloodPressure: "120/80",
      heartRate: 72,
      weight: 75,
      bloodSugar: 95,
      steps: 8500,
      waterIntake: 2.5,
      temperature: 98.6,
    },
    {
      id: "2",
      date: "2025-01-24",
      bloodPressure: "118/78",
      heartRate: 70,
      weight: 75.2,
      bloodSugar: 92,
      steps: 9200,
      waterIntake: 2.8,
      temperature: 98.5,
    },
    {
      id: "3",
      date: "2025-01-23",
      bloodPressure: "122/82",
      heartRate: 75,
      weight: 75.5,
      bloodSugar: 98,
      steps: 7800,
      waterIntake: 2.2,
      temperature: 98.7,
    },
    {
      id: "4",
      date: "2025-01-22",
      bloodPressure: "119/79",
      heartRate: 71,
      weight: 75.3,
      bloodSugar: 94,
      steps: 8900,
      waterIntake: 2.6,
      temperature: 98.6,
    },
    {
      id: "5",
      date: "2025-01-21",
      bloodPressure: "121/81",
      heartRate: 73,
      weight: 75.1,
      bloodSugar: 96,
      steps: 8200,
      waterIntake: 2.4,
      temperature: 98.5,
    },
  ])

  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split("T")[0],
    bloodPressure: "",
    heartRate: "",
    weight: "",
    bloodSugar: "",
    steps: "",
    waterIntake: "",
    temperature: "",
  })

  const handleAddMetric = () => {
    if (!formData.date) return

    const newMetric: HealthMetric = {
      id: Date.now().toString(),
      date: formData.date,
      bloodPressure: formData.bloodPressure || undefined,
      heartRate: formData.heartRate ? Number.parseInt(formData.heartRate) : undefined,
      weight: formData.weight ? Number.parseFloat(formData.weight) : undefined,
      bloodSugar: formData.bloodSugar ? Number.parseInt(formData.bloodSugar) : undefined,
      steps: formData.steps ? Number.parseInt(formData.steps) : undefined,
      waterIntake: formData.waterIntake ? Number.parseFloat(formData.waterIntake) : undefined,
      temperature: formData.temperature ? Number.parseFloat(formData.temperature) : undefined,
    }

    setMetrics([newMetric, ...metrics])
    setFormData({
      date: new Date().toISOString().split("T")[0],
      bloodPressure: "",
      heartRate: "",
      weight: "",
      bloodSugar: "",
      steps: "",
      waterIntake: "",
      temperature: "",
    })
    setShowForm(false)
  }

  const chartData = metrics
    .slice()
    .reverse()
    .map((m) => ({
      date: new Date(m.date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      heartRate: m.heartRate,
      weight: m.weight,
      bloodSugar: m.bloodSugar,
      steps: m.steps ? m.steps / 1000 : 0,
    }))

  const latestMetric = metrics[0]

  const getHealthStatus = (metric: string, value: any) => {
    if (metric === "bloodPressure") {
      const [systolic] = value.split("/").map(Number)
      if (systolic < 120) return { status: "Normal", color: "text-green-600" }
      if (systolic < 140) return { status: "Elevated", color: "text-amber-600" }
      return { status: "High", color: "text-red-600" }
    }
    if (metric === "heartRate") {
      if (value >= 60 && value <= 100) return { status: "Normal", color: "text-green-600" }
      if (value < 60) return { status: "Low", color: "text-blue-600" }
      return { status: "High", color: "text-red-600" }
    }
    if (metric === "bloodSugar") {
      if (value >= 70 && value <= 100) return { status: "Normal", color: "text-green-600" }
      if (value < 70) return { status: "Low", color: "text-blue-600" }
      return { status: "High", color: "text-red-600" }
    }
    return { status: "Normal", color: "text-green-600" }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/" className="flex items-center gap-2 text-emerald-600 hover:text-emerald-700 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
          <h1 className="text-3xl font-bold text-slate-900">Health Dashboard</h1>
          <p className="text-slate-600 mt-2">Track and monitor your health metrics over time</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Add Metric Button */}
        <div className="mb-8">
          <Button
            onClick={() => setShowForm(!showForm)}
            className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white"
            size="lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Log Health Metrics
          </Button>
        </div>

        {/* Add Metric Form */}
        {showForm && (
          <Card className="p-8 mb-8 border-slate-200">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Log Your Health Metrics</h2>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Date</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Blood Pressure</label>
                  <input
                    type="text"
                    value={formData.bloodPressure}
                    onChange={(e) => setFormData({ ...formData, bloodPressure: e.target.value })}
                    placeholder="120/80"
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Heart Rate (bpm)</label>
                  <input
                    type="number"
                    value={formData.heartRate}
                    onChange={(e) => setFormData({ ...formData, heartRate: e.target.value })}
                    placeholder="72"
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Weight (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.weight}
                    onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                    placeholder="75"
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Blood Sugar (mg/dL)</label>
                  <input
                    type="number"
                    value={formData.bloodSugar}
                    onChange={(e) => setFormData({ ...formData, bloodSugar: e.target.value })}
                    placeholder="95"
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Steps</label>
                  <input
                    type="number"
                    value={formData.steps}
                    onChange={(e) => setFormData({ ...formData, steps: e.target.value })}
                    placeholder="8500"
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Water Intake (liters)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.waterIntake}
                    onChange={(e) => setFormData({ ...formData, waterIntake: e.target.value })}
                    placeholder="2.5"
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Temperature (°C)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.temperature}
                    onChange={(e) => setFormData({ ...formData, temperature: e.target.value })}
                    placeholder="98.6"
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={handleAddMetric}
                  className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white"
                >
                  Log Metrics
                </Button>
                <Button onClick={() => setShowForm(false)} variant="outline" className="flex-1 border-slate-300">
                  Cancel
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Current Status Cards */}
        {latestMetric && (
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {latestMetric.bloodPressure && (
              <Card className="p-6 border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-slate-600">Blood Pressure</span>
                  <Heart className="w-5 h-5 text-red-500" />
                </div>
                <p className="text-2xl font-bold text-slate-900">{latestMetric.bloodPressure}</p>
                <p
                  className={`text-sm font-medium mt-1 ${getHealthStatus("bloodPressure", latestMetric.bloodPressure).color}`}
                >
                  {getHealthStatus("bloodPressure", latestMetric.bloodPressure).status}
                </p>
              </Card>
            )}
            {latestMetric.heartRate && (
              <Card className="p-6 border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-slate-600">Heart Rate</span>
                  <Activity className="w-5 h-5 text-emerald-500" />
                </div>
                <p className="text-2xl font-bold text-slate-900">{latestMetric.heartRate} bpm</p>
                <p className={`text-sm font-medium mt-1 ${getHealthStatus("heartRate", latestMetric.heartRate).color}`}>
                  {getHealthStatus("heartRate", latestMetric.heartRate).status}
                </p>
              </Card>
            )}
            {latestMetric.weight && (
              <Card className="p-6 border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-slate-600">Weight</span>
                  <Weight className="w-5 h-5 text-blue-500" />
                </div>
                <p className="text-2xl font-bold text-slate-900">{latestMetric.weight} kg</p>
                <p className="text-sm text-slate-600 mt-1">Stable</p>
              </Card>
            )}
            {latestMetric.bloodSugar && (
              <Card className="p-6 border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-slate-600">Blood Sugar</span>
                  <Droplet className="w-5 h-5 text-amber-500" />
                </div>
                <p className="text-2xl font-bold text-slate-900">{latestMetric.bloodSugar} mg/dL</p>
                <p
                  className={`text-sm font-medium mt-1 ${getHealthStatus("bloodSugar", latestMetric.bloodSugar).color}`}
                >
                  {getHealthStatus("bloodSugar", latestMetric.bloodSugar).status}
                </p>
              </Card>
            )}
          </div>
        )}

        {/* Charts */}
        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* Heart Rate Chart */}
          <Card className="p-6 border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Heart Rate Trend</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="heartRate" stroke="#10b981" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          {/* Weight Chart */}
          <Card className="p-6 border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Weight Trend</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="weight" stroke="#3b82f6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          {/* Blood Sugar Chart */}
          <Card className="p-6 border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Blood Sugar Levels</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="bloodSugar" fill="#f59e0b" />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          {/* Steps Chart */}
          <Card className="p-6 border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Daily Steps</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="steps" fill="#8b5cf6" />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Recent Entries */}
        <Card className="p-6 border-slate-200">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">Recent Entries</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left py-3 px-4 font-medium text-slate-700">Date</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">BP</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">HR</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">Weight</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">Sugar</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">Steps</th>
                </tr>
              </thead>
              <tbody>
                {metrics.slice(0, 10).map((metric) => (
                  <tr key={metric.id} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="py-3 px-4 text-slate-900">{new Date(metric.date).toLocaleDateString()}</td>
                    <td className="py-3 px-4 text-slate-600">{metric.bloodPressure || "-"}</td>
                    <td className="py-3 px-4 text-slate-600">{metric.heartRate || "-"}</td>
                    <td className="py-3 px-4 text-slate-600">{metric.weight || "-"}</td>
                    <td className="py-3 px-4 text-slate-600">{metric.bloodSugar || "-"}</td>
                    <td className="py-3 px-4 text-slate-600">{metric.steps || "-"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  )
}
