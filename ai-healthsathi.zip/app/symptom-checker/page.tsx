"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Loader2, AlertCircle, CheckCircle2 } from "lucide-react"

interface SymptomResult {
  condition: string
  severity: "mild" | "moderate" | "severe"
  description: string
  recommendations: string[]
  whenToSeekHelp: string
}

export default function SymptomChecker() {
  const [step, setStep] = useState<"input" | "loading" | "result">("input")
  const [symptoms, setSymptoms] = useState("")
  const [result, setResult] = useState<SymptomResult | null>(null)

  const commonSymptoms = [
    "Fever",
    "Cough",
    "Headache",
    "Sore Throat",
    "Body Ache",
    "Fatigue",
    "Nausea",
    "Dizziness",
    "Chest Pain",
    "Shortness of Breath",
  ]

  const handleAnalyzeSymptoms = async () => {
    if (!symptoms.trim()) return

    setStep("loading")

    // Simulate AI analysis
    setTimeout(() => {
      const mockResults: SymptomResult[] = [
        {
          condition: "Common Cold",
          severity: "mild",
          description:
            "Your symptoms suggest a common viral infection. This is typically self-limiting and resolves within 7-10 days.",
          recommendations: [
            "Rest and get adequate sleep",
            "Stay hydrated with water and warm fluids",
            "Use saline nasal drops for congestion",
            "Take vitamin C supplements",
            "Avoid smoking and secondhand smoke",
          ],
          whenToSeekHelp: "Seek medical attention if symptoms persist beyond 2 weeks or worsen significantly.",
        },
        {
          condition: "Flu (Influenza)",
          severity: "moderate",
          description:
            "Your symptoms could indicate influenza. This is more severe than a common cold and requires careful monitoring.",
          recommendations: [
            "Rest completely for at least 3-5 days",
            "Stay hydrated with electrolyte solutions",
            "Use fever-reducing medications as directed",
            "Isolate yourself to prevent spreading",
            "Monitor your temperature regularly",
          ],
          whenToSeekHelp:
            "Seek immediate medical attention if you experience difficulty breathing, chest pain, or confusion.",
        },
      ]

      setResult(mockResults[0])
      setStep("result")
    }, 2000)
  }

  const addSymptom = (symptom: string) => {
    if (!symptoms.includes(symptom)) {
      setSymptoms((prev) => (prev ? `${prev}, ${symptom}` : symptom))
    }
  }

  const removeSymptom = (symptom: string) => {
    setSymptoms((prev) => prev.replace(`, ${symptom}`, "").replace(symptom, "").trim())
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/" className="flex items-center gap-2 text-emerald-600 hover:text-emerald-700 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
          <h1 className="text-3xl font-bold text-slate-900">AI Symptom Checker</h1>
          <p className="text-slate-600 mt-2">Describe your symptoms and get instant AI-powered analysis</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {step === "input" && (
          <div className="space-y-8">
            {/* Input Section */}
            <Card className="p-8 border-slate-200">
              <h2 className="text-xl font-semibold text-slate-900 mb-4">Describe Your Symptoms</h2>
              <textarea
                value={symptoms}
                onChange={(e) => setSymptoms(e.target.value)}
                placeholder="E.g., I have a fever, cough, and sore throat for 2 days..."
                className="w-full h-32 p-4 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent resize-none"
              />
              <p className="text-sm text-slate-500 mt-2">
                Be as detailed as possible. Include duration, severity, and any other relevant information.
              </p>
            </Card>

            {/* Selected Symptoms */}
            {symptoms && (
              <Card className="p-6 border-slate-200 bg-emerald-50">
                <h3 className="font-semibold text-slate-900 mb-3">Selected Symptoms:</h3>
                <div className="flex flex-wrap gap-2">
                  {symptoms.split(",").map((symptom, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2 bg-white px-3 py-1 rounded-full border border-emerald-200"
                    >
                      <span className="text-sm text-slate-700">{symptom.trim()}</span>
                      <button
                        onClick={() => removeSymptom(symptom.trim())}
                        className="text-slate-400 hover:text-slate-600"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* Quick Add Symptoms */}
            <Card className="p-6 border-slate-200">
              <h3 className="font-semibold text-slate-900 mb-4">Common Symptoms</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
                {commonSymptoms.map((symptom) => (
                  <button
                    key={symptom}
                    onClick={() => addSymptom(symptom)}
                    className={`px-3 py-2 rounded-lg text-sm font-medium transition ${
                      symptoms.includes(symptom)
                        ? "bg-emerald-500 text-white"
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    {symptom}
                  </button>
                ))}
              </div>
            </Card>

            {/* Action Buttons */}
            <div className="flex gap-4">
              <Button
                onClick={handleAnalyzeSymptoms}
                disabled={!symptoms.trim()}
                className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white disabled:opacity-50"
                size="lg"
              >
                Analyze Symptoms
              </Button>
              <Button onClick={() => setSymptoms("")} variant="outline" className="flex-1 border-slate-300" size="lg">
                Clear
              </Button>
            </div>

            {/* Disclaimer */}
            <Card className="p-4 border-amber-200 bg-amber-50">
              <div className="flex gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-amber-900">Medical Disclaimer</p>
                  <p className="text-sm text-amber-800 mt-1">
                    This AI analysis is for informational purposes only and should not replace professional medical
                    advice. Always consult with a qualified healthcare provider for diagnosis and treatment.
                  </p>
                </div>
              </div>
            </Card>
          </div>
        )}

        {step === "loading" && (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="w-12 h-12 text-emerald-500 animate-spin mb-4" />
            <p className="text-lg text-slate-600">Analyzing your symptoms...</p>
            <p className="text-sm text-slate-500 mt-2">This may take a few moments</p>
          </div>
        )}

        {step === "result" && result && (
          <div className="space-y-6">
            {/* Result Header */}
            <Card className="p-8 border-slate-200 bg-gradient-to-br from-emerald-50 to-teal-50">
              <div className="flex items-start gap-4">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 flex-shrink-0 mt-1" />
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-slate-900">{result.condition}</h2>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-sm font-medium text-slate-600">Severity:</span>
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-medium ${
                        result.severity === "mild"
                          ? "bg-green-100 text-green-800"
                          : result.severity === "moderate"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-red-100 text-red-800"
                      }`}
                    >
                      {result.severity.charAt(0).toUpperCase() + result.severity.slice(1)}
                    </span>
                  </div>
                </div>
              </div>
            </Card>

            {/* Description */}
            <Card className="p-6 border-slate-200">
              <h3 className="font-semibold text-slate-900 mb-3">About This Condition</h3>
              <p className="text-slate-700 leading-relaxed">{result.description}</p>
            </Card>

            {/* Recommendations */}
            <Card className="p-6 border-slate-200">
              <h3 className="font-semibold text-slate-900 mb-4">Recommended Actions</h3>
              <ul className="space-y-3">
                {result.recommendations.map((rec, idx) => (
                  <li key={idx} className="flex gap-3">
                    <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-sm font-medium text-emerald-700">{idx + 1}</span>
                    </div>
                    <span className="text-slate-700">{rec}</span>
                  </li>
                ))}
              </ul>
            </Card>

            {/* When to Seek Help */}
            <Card className="p-6 border-red-200 bg-red-50">
              <div className="flex gap-3">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-red-900">When to Seek Medical Help</p>
                  <p className="text-sm text-red-800 mt-1">{result.whenToSeekHelp}</p>
                </div>
              </div>
            </Card>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={() => {
                  setStep("input")
                  setSymptoms("")
                  setResult(null)
                }}
                className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white"
                size="lg"
              >
                Check Another Symptom
              </Button>
              <Link href="/doctor-connect" className="flex-1">
                <Button className="w-full border-slate-300 bg-transparent" variant="outline" size="lg">
                  Connect with Doctor
                </Button>
              </Link>
            </div>

            {/* Disclaimer */}
            <Card className="p-4 border-amber-200 bg-amber-50">
              <div className="flex gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-amber-900">Important Notice</p>
                  <p className="text-sm text-amber-800 mt-1">
                    This analysis is AI-generated and for informational purposes only. It is not a substitute for
                    professional medical diagnosis or treatment. Please consult a healthcare provider.
                  </p>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
