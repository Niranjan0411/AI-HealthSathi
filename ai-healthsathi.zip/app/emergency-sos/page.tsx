"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, AlertTriangle, Phone, MapPin, Clock, Plus, Trash2, Edit2 } from "lucide-react"

interface EmergencyContact {
  id: string
  name: string
  relationship: string
  phone: string
  priority: "high" | "medium" | "low"
}

interface EmergencyService {
  id: string
  name: string
  type: string
  phone: string
  address: string
  distance: string
}

export default function EmergencySOS() {
  const [sosActive, setSosActive] = useState(false)
  const [showContactForm, setShowContactForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)

  const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>([
    {
      id: "1",
      name: "Rajesh Kumar",
      relationship: "Spouse",
      phone: "+91 98765 43210",
      priority: "high",
    },
    {
      id: "2",
      name: "Dr. Sharma",
      relationship: "Family Doctor",
      phone: "+91 98765 43211",
      priority: "high",
    },
    {
      id: "3",
      name: "Priya Singh",
      relationship: "Sister",
      phone: "+91 98765 43212",
      priority: "medium",
    },
  ])

  const [emergencyServices] = useState<EmergencyService[]>([
    {
      id: "1",
      name: "City General Hospital",
      type: "Hospital",
      phone: "102",
      address: "Main Road, City Center",
      distance: "2.3 km",
    },
    {
      id: "2",
      name: "Ambulance Service",
      type: "Ambulance",
      phone: "108",
      address: "24/7 Emergency Service",
      distance: "Available",
    },
    {
      id: "3",
      name: "Police Emergency",
      type: "Police",
      phone: "100",
      address: "Emergency Response",
      distance: "Available",
    },
    {
      id: "4",
      name: "Poison Control",
      type: "Medical Emergency",
      phone: "1800-11-6117",
      address: "24/7 Helpline",
      distance: "Available",
    },
  ])

  const [formData, setFormData] = useState({
    name: "",
    relationship: "",
    phone: "",
    priority: "medium" as const,
  })

  const handleAddContact = () => {
    if (!formData.name || !formData.phone) return

    if (editingId) {
      setEmergencyContacts(
        emergencyContacts.map((c) =>
          c.id === editingId
            ? {
                ...c,
                name: formData.name,
                relationship: formData.relationship,
                phone: formData.phone,
                priority: formData.priority,
              }
            : c,
        ),
      )
      setEditingId(null)
    } else {
      setEmergencyContacts([
        ...emergencyContacts,
        {
          id: Date.now().toString(),
          name: formData.name,
          relationship: formData.relationship,
          phone: formData.phone,
          priority: formData.priority,
        },
      ])
    }

    setFormData({
      name: "",
      relationship: "",
      phone: "",
      priority: "medium",
    })
    setShowContactForm(false)
  }

  const handleDeleteContact = (id: string) => {
    setEmergencyContacts(emergencyContacts.filter((c) => c.id !== id))
  }

  const handleEditContact = (contact: EmergencyContact) => {
    setFormData({
      name: contact.name,
      relationship: contact.relationship,
      phone: contact.phone,
      priority: contact.priority,
    })
    setEditingId(contact.id)
    setShowContactForm(true)
  }

  const handleSOS = () => {
    setSosActive(true)
    // In a real app, this would trigger notifications to emergency contacts
    setTimeout(() => {
      alert("SOS activated! Emergency contacts have been notified.")
      setSosActive(false)
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/" className="flex items-center gap-2 text-emerald-600 hover:text-emerald-700 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
          <h1 className="text-3xl font-bold text-slate-900">Emergency SOS</h1>
          <p className="text-slate-600 mt-2">Quick access to emergency services and contacts</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* SOS Button */}
        <div className="mb-12">
          <button
            onClick={handleSOS}
            disabled={sosActive}
            className={`w-full py-16 rounded-2xl font-bold text-2xl transition transform hover:scale-105 active:scale-95 ${
              sosActive
                ? "bg-red-600 text-white animate-pulse"
                : "bg-gradient-to-br from-red-500 to-red-700 text-white hover:from-red-600 hover:to-red-800"
            }`}
          >
            <div className="flex flex-col items-center gap-4">
              <AlertTriangle className="w-16 h-16" />
              <span>{sosActive ? "SOS ACTIVATED" : "PRESS FOR EMERGENCY SOS"}</span>
            </div>
          </button>
          <p className="text-center text-sm text-slate-600 mt-4">
            Hold or tap the button above to activate emergency SOS. This will notify all your emergency contacts.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Emergency Contacts */}
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-slate-900">Emergency Contacts</h2>
              <Button
                onClick={() => {
                  setShowContactForm(!showContactForm)
                  setEditingId(null)
                  setFormData({
                    name: "",
                    relationship: "",
                    phone: "",
                    priority: "medium",
                  })
                }}
                size="sm"
                className="bg-emerald-500 hover:bg-emerald-600 text-white"
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Contact
              </Button>
            </div>

            {/* Add Contact Form */}
            {showContactForm && (
              <Card className="p-6 mb-6 border-slate-200">
                <h3 className="font-semibold text-slate-900 mb-4">
                  {editingId ? "Edit Contact" : "Add Emergency Contact"}
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Name</label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Contact name"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Relationship</label>
                    <input
                      type="text"
                      value={formData.relationship}
                      onChange={(e) => setFormData({ ...formData, relationship: e.target.value })}
                      placeholder="E.g., Spouse, Doctor, Sister"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+91 98765 43210"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Priority</label>
                    <select
                      value={formData.priority}
                      onChange={(e) => setFormData({ ...formData, priority: e.target.value as any })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="high">High</option>
                      <option value="medium">Medium</option>
                      <option value="low">Low</option>
                    </select>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={handleAddContact}
                      className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white"
                    >
                      {editingId ? "Update" : "Add"}
                    </Button>
                    <Button
                      onClick={() => {
                        setShowContactForm(false)
                        setEditingId(null)
                      }}
                      variant="outline"
                      className="flex-1 border-slate-300"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              </Card>
            )}

            {/* Contacts List */}
            <div className="space-y-3">
              {emergencyContacts.map((contact) => (
                <Card
                  key={contact.id}
                  className={`p-4 border-2 ${
                    contact.priority === "high"
                      ? "border-red-200 bg-red-50"
                      : contact.priority === "medium"
                        ? "border-amber-200 bg-amber-50"
                        : "border-slate-200"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-900">{contact.name}</h3>
                      <p className="text-sm text-slate-600">{contact.relationship}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Phone className="w-4 h-4 text-slate-500" />
                        <a href={`tel:${contact.phone}`} className="text-sm text-emerald-600 hover:underline">
                          {contact.phone}
                        </a>
                      </div>
                      <span
                        className={`inline-block mt-2 px-2 py-1 text-xs font-medium rounded ${
                          contact.priority === "high"
                            ? "bg-red-200 text-red-800"
                            : contact.priority === "medium"
                              ? "bg-amber-200 text-amber-800"
                              : "bg-slate-200 text-slate-800"
                        }`}
                      >
                        {contact.priority.charAt(0).toUpperCase() + contact.priority.slice(1)} Priority
                      </span>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleEditContact(contact)}
                        className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteContact(contact.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Emergency Services */}
          <div>
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Emergency Services</h2>
            <div className="space-y-3">
              {emergencyServices.map((service) => (
                <Card key={service.id} className="p-4 border-slate-200 hover:shadow-lg transition">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-900">{service.name}</h3>
                      <p className="text-sm text-slate-600 mb-2">{service.type}</p>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Phone className="w-4 h-4 text-slate-500" />
                          <a
                            href={`tel:${service.phone}`}
                            className="text-sm font-medium text-emerald-600 hover:underline"
                          >
                            {service.phone}
                          </a>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-slate-500" />
                          <span className="text-sm text-slate-600">{service.address}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-slate-500" />
                          <span className="text-sm text-slate-600">{service.distance}</span>
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => (window.location.href = `tel:${service.phone}`)}
                      className="bg-red-500 hover:bg-red-600 text-white whitespace-nowrap"
                      size="sm"
                    >
                      Call Now
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>

        {/* Safety Tips */}
        <Card className="mt-12 p-6 border-blue-200 bg-blue-50">
          <div className="flex gap-3">
            <AlertTriangle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-blue-900">Emergency Safety Tips</p>
              <ul className="text-sm text-blue-800 mt-2 space-y-1">
                <li>• Always keep your emergency contacts updated</li>
                <li>• Ensure your phone is charged and accessible</li>
                <li>• Share your location with trusted contacts</li>
                <li>• Know the emergency numbers in your area</li>
                <li>• In life-threatening situations, always call emergency services first</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
