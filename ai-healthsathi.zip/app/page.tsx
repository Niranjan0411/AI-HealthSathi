"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Heart, Pill, AlertCircle, BarChart3, Users, Smile, Menu, X } from "lucide-react"

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const features = [
    {
      icon: Heart,
      title: "Symptom Checker",
      description: "AI-powered symptom analysis in your local language",
      href: "/symptom-checker",
      color: "from-emerald-500 to-teal-600",
    },
    {
      icon: Pill,
      title: "Medicine Reminders",
      description: "Never miss a dose with smart reminders",
      href: "/medicine-reminders",
      color: "from-blue-500 to-cyan-600",
    },
    {
      icon: AlertCircle,
      title: "Emergency SOS",
      description: "Quick access to emergency contacts and services",
      href: "/emergency-sos",
      color: "from-red-500 to-orange-600",
    },
    {
      icon: BarChart3,
      title: "Health Dashboard",
      description: "Track your health metrics and progress",
      href: "/health-dashboard",
      color: "from-purple-500 to-pink-600",
    },
    {
      icon: Users,
      title: "Doctor Connect",
      description: "Connect with healthcare professionals",
      href: "/doctor-connect",
      color: "from-indigo-500 to-blue-600",
    },
    {
      icon: Smile,
      title: "Health Tips & Wellness",
      description: "Daily health tips and emotional support",
      href: "/health-tips",
      color: "from-amber-500 to-orange-600",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-lg flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-slate-900">HealthSathi</span>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-8">
              <Link href="#features" className="text-slate-600 hover:text-slate-900 transition">
                Features
              </Link>
              <Link href="#about" className="text-slate-600 hover:text-slate-900 transition">
                About
              </Link>
              <Button className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white">
                Get Started
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X className="w-6 h-6 text-slate-900" /> : <Menu className="w-6 h-6 text-slate-900" />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden pb-4 space-y-2">
              <Link href="#features" className="block px-4 py-2 text-slate-600 hover:bg-slate-100 rounded">
                Features
              </Link>
              <Link href="#about" className="block px-4 py-2 text-slate-600 hover:bg-slate-100 rounded">
                About
              </Link>
              <Button className="w-full bg-gradient-to-r from-emerald-500 to-teal-600">Get Started</Button>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-slate-900 leading-tight">
              Your AI Health Guardian
            </h1>
            <p className="text-lg text-slate-600 leading-relaxed">
              HealthSathi brings intelligent healthcare to your fingertips. Get instant symptom analysis, medicine
              reminders, and health guidance in your local language—anytime, anywhere.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white"
              >
                Start Your Journey
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-slate-300 text-slate-900 hover:bg-slate-50 bg-transparent"
              >
                Learn More
              </Button>
            </div>
          </div>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/20 to-teal-400/20 rounded-3xl blur-3xl"></div>
            <div className="relative bg-gradient-to-br from-emerald-50 to-teal-50 rounded-3xl p-8 border border-emerald-200">
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-4 bg-white rounded-xl border border-emerald-100">
                  <Heart className="w-5 h-5 text-emerald-600" />
                  <span className="text-sm font-medium text-slate-900">Real-time Health Monitoring</span>
                </div>
                <div className="flex items-center gap-3 p-4 bg-white rounded-xl border border-emerald-100">
                  <Pill className="w-5 h-5 text-blue-600" />
                  <span className="text-sm font-medium text-slate-900">Smart Medicine Reminders</span>
                </div>
                <div className="flex items-center gap-3 p-4 bg-white rounded-xl border border-emerald-100">
                  <AlertCircle className="w-5 h-5 text-red-600" />
                  <span className="text-sm font-medium text-slate-900">Emergency SOS Access</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="bg-gradient-to-b from-slate-50 to-white py-20 md:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
              Comprehensive Healthcare at Your Fingertips
            </h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Everything you need for better health management, powered by AI and designed for accessibility
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon
              return (
                <Link key={index} href={feature.href}>
                  <Card className="h-full hover:shadow-lg transition-all duration-300 cursor-pointer border-slate-200 hover:border-slate-300 group">
                    <div className="p-6 space-y-4">
                      <div
                        className={`w-12 h-12 rounded-lg bg-gradient-to-br ${feature.color} flex items-center justify-center group-hover:scale-110 transition-transform`}
                      >
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="text-xl font-semibold text-slate-900">{feature.title}</h3>
                      <p className="text-slate-600">{feature.description}</p>
                      <div className="pt-2 text-emerald-600 font-medium text-sm group-hover:translate-x-1 transition-transform">
                        Explore →
                      </div>
                    </div>
                  </Card>
                </Link>
              )
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-emerald-500 to-teal-600 py-16 md:py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Ready to Take Control of Your Health?</h2>
          <p className="text-lg text-emerald-50 mb-8">
            Join thousands of users who are already using HealthSathi for better health management
          </p>
          <Button size="lg" className="bg-white text-emerald-600 hover:bg-slate-50 font-semibold">
            Get Started Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-lg flex items-center justify-center">
                  <Heart className="w-5 h-5 text-white" />
                </div>
                <span className="font-bold text-white">HealthSathi</span>
              </div>
              <p className="text-sm">Your AI Health Guardian</p>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Features</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="hover:text-white transition">
                    Symptom Checker
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition">
                    Health Dashboard
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition">
                    Doctor Connect
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="hover:text-white transition">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="hover:text-white transition">
                    Privacy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition">
                    Terms
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition">
                    Disclaimer
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-8 text-center text-sm">
            <p>&copy; 2025 HealthSathi. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
